<?php

namespace Drupal\Core\Asset\Exception;

/**
 * Defines an exception if the library file could not be parsed.
 */
class InvalidLibraryFileException extends \RunTimeException {

}
